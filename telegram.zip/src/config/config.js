import * as dotenv from 'dotenv';
dotenv.config();

const token = process.env.BOT_TOKEN;

export default token;