const admins = {
    channel_id : [
        -1002336342829
    ]
};

export default admins;
